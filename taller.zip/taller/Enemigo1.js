class Enemigo1 extends Enemigo{
    
    Enemigo1(){

    }
}