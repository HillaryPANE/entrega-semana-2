class Enemigo{
    
    Enemigo(){

    }
}