
new p5(function (app) {

    let personaje;


    app.setup = function () {
        app.createCanvas(900, 900);
        personaje = new Personaje(app, 800, 450, 50, 60);
        balas = [];

        //
        //this.imagen = this.app.loadImage('./src/img/imagen.png');
        //Esto va en el boton de disparo
        //this.balas.push(new Bala(app,x,y..etc))
    }
    //al parecer es como el size en java.

    app.draw = function () {
        app.background(0);
        personaje.pintarPersonaje();

        
        for (let i = 0; i < balas.length; i++) {
            const bala = balas[i];
            bala.pintarBala();
        }
        
    }

    app.keyPressed = function () {

        //Ir a la derecha
        if (app.keyCode == app.RIGHT_ARROW && personaje.matX < 880) {
            personaje.matX += 20;
        }

        //Ir a la izquierda
        if (app.keyCode == app.LEFT_ARROW && personaje.matX > 20) {
            personaje.matX -= 20;
        }

        // if disparo
        // => new Bala
        // ==> add new Bala to balas
        if(app.key == ' ' ){
            balas.push(new Bala(app,personaje.matX,personaje.matY,20,20));
        }
    }
});
