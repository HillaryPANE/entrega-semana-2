class Enemigo2 extends Enemigo{
    
    Enemigo2(){

    }
}